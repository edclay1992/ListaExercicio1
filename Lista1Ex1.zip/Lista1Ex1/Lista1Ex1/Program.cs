﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int b;
            int h;
            int a;

            Console.WriteLine("Digite a base do retangulo ");
            b = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite a altura do retangulo ");
            h = int.Parse(Console.ReadLine());

            a = b * h;

            Console.WriteLine("A área de um retângulo que tem base {0} e altura {1} é {2}", b, h, a);
        }
    }
}
